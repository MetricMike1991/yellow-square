# Yellow Square Plugin

A simple WordPress plugin that provides a shortcode `[yellow_square]` to display a yellow square centered on a baby blue background.

## Usage

1. Upload the `yellow-square-plugin` folder to your WordPress `wp-content/plugins` directory.
2. Activate the plugin from the WordPress admin panel.
3. Use the `[yellow_square]` shortcode in any post or page.
